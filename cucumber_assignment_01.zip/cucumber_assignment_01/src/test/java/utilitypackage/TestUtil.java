package utilitypackage;

public class TestUtil {

	public static int PAGE_LOAD_TIMEOUT=30;
	public static int IMPLICIT_WAIT=30;
	

}
